
library(dplyr)
library(tidyverse)
library(glmmTMB)
library(ggeffects)   # For ggpredict
library(ggplot2) 


dataset_fishstability<-read.csv("dataset.csv")

##### Part: Figure S1-3 and statistical tables
summary(model_full<-glmmTMB(  CV_community_ln ~ 
                                
                                scale(length_ln)+
                                scale(lattitude_abs)+
                                
                                scale(deoxgen_rate)*scale(species_richness_ln)+
                                scale(deoxgen_rate)*type +
                                scale(deoxgen_rate)*scale(warming_rate)+
                                scale(deoxgen_rate)*scale(proportion_endangered)+
                                
                                (1 | type), 
                              data = dataset_fishstability, family = gaussian())) 


############ Figure S1
# correlation: Ln(species richenss) and Threatened-species proportion with your variable names
dat_cor <- dataset_fishstability %>% dplyr::select(species_richness_ln, proportion_endangered) %>%filter(complete.cases(.))
# Pearson correlation
cor_res <- cor.test( dat_cor$species_richness_ln, dat_cor$proportion_endangered,method = "pearson")
# Extract r and P
r <- unname(cor_res$estimate) #r=-0.48, P<0.001
p <- cor_res$p.value
# Format P value
p_text <- ifelse(p < 0.001,"P < 0.001",paste0("P = ", formatC(p, format = "f", digits = 3)))
# Plot
ggplot(dat_cor, aes(x = species_richness_ln, y = proportion_endangered)) +geom_point(size = 2, alpha = 0.7) +geom_smooth(method = "lm",se = TRUE,linewidth = 1) +
  labs(x = "Ln(species richenss)",y = "Threatened-species proportion",subtitle = paste0("Pearson's r = ", round(r, 2),", ", p_text)) +
  theme_classic(base_size = 14) +theme( plot.subtitle = element_text(hjust = 0.5,face = "bold" ))+ 
  theme(legend.position = "bottom",plot.title = element_text(hjust = 0.5, size = 11),axis.title.x = element_text( size = 11),
        axis.text.x = element_text(face = "bold", size = 10),axis.title.y = element_text(size = 12),
        axis.text.y = element_text(face = "bold", size = 10),legend.title = element_blank(),
        legend.text = element_text(size = 10))+scale_y_continuous(limits = c(-0.2, 0.6))

ggsave(filename = "Fig S1.png", width = 100, height = 100, dpi = 600, units = "mm", device='png')





############ Figure S2
#####  lattitude_abs
p1 <- ggpredict(model_full, c("lattitude_abs"))
p1 <- as.data.frame(p1)

Fig1_CS <- ggplot(p1, aes(x = x, y = predicted)) +
  
  # 95% CI of model prediction
  geom_ribbon(
    aes(ymin = conf.low, ymax = conf.high),
    alpha = 0.18
  ) +
  
  # Raw observations
  geom_point(
    data = dataset_fishstability,
    aes(x = lattitude_abs, y = CV_community_ln),
    inherit.aes = FALSE,
    alpha = 0.35,
    shape=20, 
    size = 3,
    color="#00A9FF"
  ) +
  
  # Model prediction
  geom_line(linewidth = 1, color = "black") +
  
  theme_bw() +
  
  labs(
    title = "",
    x = "Ln( abs[latitude] )",
    y = expression(
      atop(
        #"Ln(temporal stability of fish community)",
        "Ln(fish community stability)",
        #"Ln(Community stability [whole fish])",
        #"Ln(Community stability) - all fish ",
        paste(" higher stability", bold(symbol('\256')))
      )
    )
  ) +
  
  theme(legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 11),
        
        axis.title.x = element_text( size = 11),
        axis.text.x = element_text(face = "bold", size = 10),
        axis.title.y = element_text(size = 12),
        axis.text.y = element_text(face = "bold", size = 10),
        legend.title = element_blank(),
        legend.text = element_text(size = 10))

Fig1_CS



ggsave(filename = "Fig S2.png", width = 90, height = 90, dpi = 600, units = "mm", device='png')




#####  Fig S3
p1 <- ggpredict(model_full, c("length_ln"))
p1 <- as.data.frame(p1)

Fig1_Cd <- ggplot(p1, aes(x = x, y = predicted)) +
  
  # 95% CI of model prediction
  #geom_ribbon(aes(ymin = conf.low, ymax = conf.high),alpha = 0.18) +
  
  # Raw observations
  geom_point(
    data = dataset_fishstability,
    aes(x = length_ln, y = CV_community_ln),
    inherit.aes = FALSE,
    alpha = 0.35,
    shape=20, 
    size = 3,
    color="black"
  ) +
  
  # Model prediction
  geom_line(linewidth = 1,linetype="dashed", color = "blue") +
  
  theme_bw() +
  
  labs(
    title = "",
    x = "Ln(time-series length [years])",
    y = expression(
      atop(
        #"Ln(temporal stability of fish community)",
        "Ln(fish community stability)",
        #"Ln(Community stability [whole fish])",
        #"Ln(Community stability) - all fish ",
        paste(" higher stability", bold(symbol('\256')))
      )
    )
  ) +
  
  theme(legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 11),
        
        axis.title.x = element_text( size = 11),
        axis.text.x = element_text(face = "bold", size = 10),
        axis.title.y = element_text(size = 12),
        axis.text.y = element_text(face = "bold", size = 10),
        legend.title = element_blank(),
        legend.text = element_text(size = 10))

Fig1_Cd


ggsave(filename = "Fig S3.png", width = 90, height = 90, dpi = 600, units = "mm", device='png')
