
library(dplyr)
library(tidyverse)
library(glmmTMB)
library(ggeffects)   # For ggpredict
library(ggplot2) 


dataset_fishstability<-read.csv("dataset.csv")

##### Part: Figure 2, table 1
summary(model_full<-glmmTMB(  CV_community_ln ~ 
                                
                                scale(length_ln)+
                                scale(lattitude_abs)+
                                
                                scale(deoxgen_rate)*scale(species_richness_ln)+
                                scale(deoxgen_rate)*type +
                                scale(deoxgen_rate)*scale(warming_rate)+
                                scale(deoxgen_rate)*scale(proportion_endangered)+
                                
                                (1 | type), 
                              data = dataset_fishstability, family = gaussian())) 


#####  proportion_red_species
p1 <- ggpredict(model_full, c("proportion_endangered"))
p1 <- as.data.frame(p1)

Fig1_CS <- ggplot(p1, aes(x = x, y = predicted)) +
  
  # 95% CI of model prediction
  geom_ribbon(
    aes(ymin = conf.low, ymax = conf.high),
    alpha = 0.18
  ) +
  
  # Raw observations
  geom_point(
    data = dataset_fishstability,
    aes(x = proportion_endangered, y = CV_community_ln),
    inherit.aes = FALSE,
    alpha = 0.35,
    shape=20, 
    size = 3,
    color="#00A9FF"
  ) +
  
  # Model prediction
  geom_line(linewidth = 1, color = "black") +
  
  theme_bw() +
  
  labs(
    title = "Threatened species proportion",
    x = "Threatened species proportion",
    y = expression(
      atop(
        #"Ln(temporal stability of fish community)",
        "Ln(fish community stability)",
        #"Ln(Community stability [whole fish])",
        #"Ln(Community stability) - all fish ",
        paste(" higher stability", bold(symbol('\256')))
      )
    )
  ) +
  
  theme(legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 11),
        
        axis.title.x = element_text( size = 11),
        axis.text.x = element_text(face = "bold", size = 10),
        axis.title.y = element_text(size = 12),
        axis.text.y = element_text(face = "bold", size = 10),
        legend.title = element_blank(),
        legend.text = element_text(size = 10))

Fig1_CS



#####  warming_rate
#Extract the actual model data
model_data <- insight::get_data(model_full)
#Calculate warming percentiles
warming_q <- quantile(model_data$warming_rate,probs = c(0.05, 0.50, 0.95),na.rm = TRUE)
# Generate predicted trends at the three percentiles
p1 <- ggpredict(model_full,terms = list(deoxgen_rate  = "all",warming_rate = unname(warming_q)))
p1 <- as.data.frame(p1)

historical_temp <- c("Low"= "#2C7BB6",  "Medium" = "#4DAF4A",   "High"= "#D73027"  )
p1$historical_temp[p1$group=="-0.03"]<-"Low";p1$historical_temp[p1$group=="0.023"]<-"Medium";p1$historical_temp[p1$group=="0.069"]<-"High"
Fig2_CS<-ggplot(p1, aes(x = x, y = predicted, color = historical_temp, fill = historical_temp)) +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high), alpha = 0.18, color = NA) +
  geom_line(linewidth = 1)+
  theme_bw() +
  #theme_minimal()+
  scale_color_manual(values = historical_temp, breaks = c("Low","Medium","High")) +
  scale_fill_manual(values = historical_temp,  breaks = c("Low","Medium","High")) +
  labs(
    title = "Deoxygenation � Warming",
    x=expression(paste(bold(symbol('\254'))," Deoxygenation [mg per litre/year]")),
    y=expression(
      atop(
        #"Ln(temporal stability of fish community)",
        "Ln(fish community stability)",
        #"Ln(Community stability [whole fish])",
        #"Ln(Community stability) - all fish ",
        paste(" higher stability",bold(symbol('\256'))))),
    
    color = "warming rate",
    fill  = "warming rate" )+
  theme(legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 11),
        
        axis.title.x = element_text(face = "bold", size = 11),
        axis.text.x = element_text(face = "bold", size = 10),
        axis.title.y = element_text(size = 12),
        axis.text.y = element_text(face = "bold", size = 10),
        legend.title = element_blank(),
        legend.text = element_text(size = 10))+
  guides(color = guide_legend(nrow = 2,byrow = TRUE),fill = guide_legend(nrow = 2,byrow = TRUE))+scale_y_continuous(limits = c(-2, 2.5)) 

Fig2_CS


#####  type
p1 <- ggpredict(model_full, c("deoxgen_rate [all]", "type"))
p1 <- as.data.frame(p1)


library(dplyr)

cols <- c("fresh water" = "#619CFF","ocean" = "#F8766D")
p1 <- p1 %>% mutate(ecosystem = case_when(group == "Fresh_water" ~ "fresh water",group == "Ocean" ~ "ocean",TRUE ~ as.character(group)),
                    ecosystem = factor(ecosystem, levels = c("fresh water", "ocean"))) %>% arrange(ecosystem, x)

dataset_fishstability <- dataset_fishstability %>%mutate(ecosystem = case_when(type %in% c("Fresh_water", "fresh water", "Freshwater") ~ "fresh water", 
                                                 type %in% c("Ocean", "ocean", "Marine") ~ "ocean",TRUE ~ as.character(type)),
                           ecosystem = factor(ecosystem, levels = c("fresh water", "ocean")))

Fig3_CS <- ggplot() +
  geom_ribbon(data = p1,aes(x = x, ymin = conf.low, ymax = conf.high,fill = ecosystem, group = ecosystem),alpha = 0.18,color = NA) +
  #geom_point(data = dataset_fishstability,aes(x = deoxgen_rate, y = CV_community_ln, color = ecosystem),alpha = 0.55,size = 2) +
  geom_point(data = subset(dataset_fishstability, ecosystem == "fresh water"),aes(x = deoxgen_rate, y = CV_community_ln, color = ecosystem),alpha = 0.55,size = 2.5) +
  geom_point(data = subset(dataset_fishstability, ecosystem == "ocean"), aes(x = deoxgen_rate, y = CV_community_ln, color = ecosystem),alpha = 0.55,size = 2.5 ) +
  geom_line(data = p1,aes(x = x, y = predicted, color = ecosystem, group = ecosystem),linewidth = 1) +
  theme_bw() +
  #theme_minimal()+
  scale_color_manual(values = cols, drop = FALSE) +
  scale_fill_manual(values = cols, drop = FALSE) +
  labs(title = "Deoxygenation � Ecosystem type",x = expression(paste(bold(symbol('\254')), " Deoxygenation [mg per litre/year]")),
       y = expression(atop(
         #"Ln(temporal stability of fish community)",
         "Ln(fish community stability)",
         #"Ln(Community stability [whole fish])",
         #"Ln(Community stability) - all fish ",
         paste(" higher stability", bold(symbol('\256'))))),
       color = "ecosystem type",fill  = "ecosystem type" ) +
  theme(legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 11),
        
        axis.title.x = element_text(face = "bold", size = 11),
        axis.text.x = element_text(face = "bold", size = 10),
        axis.title.y = element_text(size = 12),
        axis.text.y = element_text(face = "bold", size = 10),
        legend.title = element_blank(),
        legend.text = element_text(size = 10))+
  guides(color = guide_legend(nrow = 2,byrow = TRUE),fill = guide_legend(nrow = 2,byrow = TRUE)) 

Fig3_CS



#####  species_richness_ln
#Extract the actual model data
model_data <- insight::get_data(model_full)
#Calculate warming percentiles
warming_q <- quantile(model_data$species_richness_ln,probs = c(0.05, 0.50, 0.95),na.rm = TRUE)
# Generate predicted trends at the three percentiles
p1 <- ggpredict(model_full,terms = list(deoxgen_rate  = "all",species_richness_ln = unname(warming_q)))
p1 <- as.data.frame(p1)

historical_temp <- c("Low"= "#619CFF",  "Medium" = "#4DAF4A",   "High"= "#F8766D"  )
p1$historical_temp[p1$group=="1.098612289"]<-"Low";p1$historical_temp[p1$group=="2.397895273"]<-"Medium";p1$historical_temp[p1$group=="3.713572067"]<-"High"
Fig4_CS<-ggplot(p1, aes(x = x, y = predicted, color = historical_temp, fill = historical_temp)) +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high), alpha = 0.18, color = NA) +
  geom_line(linewidth = 1)+
  theme_bw() +
  #theme_minimal()+
  scale_color_manual(values = historical_temp, breaks = c("Low","Medium","High")) +
  scale_fill_manual(values = historical_temp,  breaks = c("Low","Medium","High")) +
  labs(
    title = "Deoxygenation � Species richness",
    x=expression(paste(bold(symbol('\254'))," Deoxygenation [mg per litre/year]")),
    y=expression(atop(
      #"Ln(temporal stability of fish community)",
      "Ln(fish community stability)",
      #"Ln(Community stability [whole fish])",
      #"Ln(Community stability) - all fish ",
      paste(" higher stability",bold(symbol('\256'))))),
    
    color = "species richness",
    fill  = "species richness" )+
  theme(legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 11),
        
        axis.title.x = element_text(face = "bold", size = 11),
        axis.text.x = element_text(face = "bold", size = 10),
        axis.title.y = element_text(size = 12),
        axis.text.y = element_text(face = "bold", size = 10),
        legend.title = element_blank(),
        legend.text = element_text(size = 10))+
  guides(color = guide_legend(nrow = 2,byrow = TRUE),fill = guide_legend(nrow = 2,byrow = TRUE)) 



Fig4_CS




##################################
library(cowplot)
X11(width=18, height=18)

#legend_b <- get_legend( fig3_deoxgenation_f +guides(color = guide_legend(nrow = 1)) + theme(legend.position = "bottom"))

prow <-plot_grid(
  
  Fig3_CS + theme(legend.position="bottom"),
  Fig2_CS + theme(legend.position="bottom"),
  Fig4_CS+ theme(legend.position="bottom"),
  Fig1_CS + theme(legend.position="bottom"),
  #Fig4 + theme(legend.position="none"),
  align = 'vh',
  labels = c("a","b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l"),
  label_size = 12,
  hjust = -0,
  ncol  = 2,
  nrow  = 2)

plot_grid(prow) #0.1 is lengend 0.1 height


ggsave(filename = "Fig 2.png", width = 200, height = 200, dpi = 900, units = "mm", device='png')




########################## species stability
dataset_fishstability$Average_species_stability_weighted_ln<-log(dataset_fishstability$Average_species_stability_weighted)

summary(model_full_2<-glmmTMB(Average_species_stability_weighted_ln ~ 
                                
                                scale(length_ln)+
                                scale(lattitude_abs)+
                                
                                scale(deoxgen_rate)*scale(species_richness_ln)+
                                scale(deoxgen_rate)*type +
                                scale(deoxgen_rate)*scale(warming_rate)+
                                scale(deoxgen_rate)*scale(proportion_endangered)+
                                (1 | type), 
                              data = dataset_fishstability, family = gaussian())) # deoxgen_rate PH_rate



#####  proportion_red_species
p1 <- ggpredict(model_full_2, c("proportion_endangered"))
p1 <- as.data.frame(p1)

Fig1_ps <- ggplot(p1, aes(x = x, y = predicted)) +
  
  # 95% CI of model prediction
  geom_ribbon(
    aes(ymin = conf.low, ymax = conf.high),
    alpha = 0.18
  ) +
  
geom_line(linewidth = 1, color = "black") +
  
  theme_bw() +
  
  labs(
    title = "Threatened species proportion",
    x = "Threatened species proportion",
    #y=expression(atop("Ln(species stability)",paste(" higher stability",bold(symbol('\256'))))),
    y="Ln(species stability)",
    #y="Ln(Species stability [whole fish])",
  ) +
  
  theme(
    legend.position = "bottom",
    plot.title = element_text(hjust = 0.5, size = 11),
    axis.title.x = element_text(size = 11),
    axis.text.x = element_text(face = "bold", size = 10),
    axis.title.y = element_text( size = 12),
    axis.text.y = element_text(face = "bold", size = 10),
    legend.title = element_blank(),
    legend.text = element_text(size = 10))+ scale_y_continuous(limits = c(-1, 1.2))

Fig1_ps



#####  warming_rate
#Extract the actual model data
model_data <- insight::get_data(model_full_2)
#Calculate warming percentiles
warming_q <- quantile(model_data$warming_rate,probs = c(0.05, 0.50, 0.95),na.rm = TRUE)
# Generate predicted trends at the three percentiles
p1 <- ggpredict(model_full_2,terms = list(deoxgen_rate  = "all",warming_rate = unname(warming_q)))
p1 <- as.data.frame(p1)

historical_temp <- c("Low"= "#2C7BB6",  "Medium" = "#4DAF4A",   "High"= "#D73027"  )
p1$historical_temp[p1$group=="-0.03"]<-"Low";p1$historical_temp[p1$group=="0.023"]<-"Medium";p1$historical_temp[p1$group=="0.069"]<-"High"
Fig2_ps<-ggplot(p1, aes(x = x, y = predicted, color = historical_temp, fill = historical_temp)) +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high), alpha = 0.18, color = NA) +
  geom_line(linewidth = 1)+
  theme_bw() +
  #theme_minimal()+
  scale_color_manual(values = historical_temp, breaks = c("Low","Medium","High")) +
  scale_fill_manual(values = historical_temp,  breaks = c("Low","Medium","High")) +
  labs(
    title = "Deoxygenation � Warming",
    x=expression(paste(bold(symbol('\254'))," Deoxygenation [mg per litre/year]")),
    #y=expression(atop("Ln(species stability)",paste(" higher stability",bold(symbol('\256'))))),
    y="Ln(species stability)",
    #y="Ln(Species stability [whole fish])",
    
    color = "warming rate",
    fill  = "warming rate" )+
  theme(legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 11),
        
        axis.title.x = element_text(face = "bold", size = 11),
        axis.text.x = element_text(face = "bold", size = 10),
        axis.title.y = element_text(size = 12),
        axis.text.y = element_text(face = "bold", size = 10),
        legend.title = element_blank(),
        legend.text = element_text(size = 10))+
  guides(color = guide_legend(nrow = 2,byrow = TRUE),fill = guide_legend(nrow = 2,byrow = TRUE))+scale_y_continuous(limits = c(-3, 2.2))

Fig2_ps


#####  type
p1 <- ggpredict(model_full_2, c("deoxgen_rate [all]", "type"))
p1 <- as.data.frame(p1)

library(dplyr)

cols <- c("fresh water" = "#619CFF","ocean" = "#F8766D")
p1 <- p1 %>% mutate(ecosystem = case_when(group == "Fresh_water" ~ "fresh water",group == "Ocean" ~ "ocean",TRUE ~ as.character(group)),
                    ecosystem = factor(ecosystem, levels = c("fresh water", "ocean"))) %>% arrange(ecosystem, x)

dataset_fishstability <- dataset_fishstability %>%mutate(ecosystem = case_when(type %in% c("Fresh_water", "fresh water", "Freshwater") ~ "fresh water", 
                                                 type %in% c("Ocean", "ocean", "Marine") ~ "ocean",TRUE ~ as.character(type)),
                           ecosystem = factor(ecosystem, levels = c("fresh water", "ocean")))

Fig3_ps <- ggplot() +
  geom_ribbon(data = p1,aes(x = x, ymin = conf.low, ymax = conf.high,fill = ecosystem, group = ecosystem),alpha = 0.18,color = NA) +
  #geom_point(data = subset(dataset_fishstability, ecosystem == "fresh water"),aes(x = deoxgen_rate, y = Average_species_stability_weighted_ln, color = ecosystem),alpha = 0.55,size = 2.5) +
  #geom_point(data = subset(dataset_fishstability, ecosystem == "ocean"), aes(x = deoxgen_rate, y = Average_species_stability_weighted_ln, color = ecosystem),alpha = 0.55,size = 2.5 ) +
  geom_line(data = p1,aes(x = x, y = predicted, color = ecosystem, group = ecosystem),linewidth = 1) +
  theme_bw() +
  #theme_minimal()+
  scale_color_manual(values = cols, drop = FALSE) +
  scale_fill_manual(values = cols, drop = FALSE) +
  labs(title = "Deoxygenation � Ecosystem type",x = expression(paste(bold(symbol('\254')), " Deoxygenation [mg per litre/year]")),
       #y=expression(atop("Ln(species stability)",paste(" higher stability",bold(symbol('\256'))))),
       y="Ln(species stability)",
       #y="Ln(Species stability [whole fish])",
       color = "ecosystem type",fill  = "ecosystem type" ) +
  theme(legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 11),
        
        axis.title.x = element_text(face = "bold", size = 11),
        axis.text.x = element_text(face = "bold", size = 10),
        axis.title.y = element_text(size = 12),
        axis.text.y = element_text(face = "bold", size = 10),
        legend.title = element_blank(),
        legend.text = element_text(size = 10))+
  guides(color = guide_legend(nrow = 2,byrow = TRUE),fill = guide_legend(nrow = 2,byrow = TRUE)) +scale_y_continuous(limits = c(-3, 2.2))

Fig3_ps



#####  species_richness_ln
#Extract the actual model data
model_data <- insight::get_data(model_full_2)
#Calculate warming percentiles
warming_q <- quantile(model_data$species_richness_ln,probs = c(0.05, 0.50, 0.95),na.rm = TRUE)
# Generate predicted trends at the three percentiles
p1 <- ggpredict(model_full_2,terms = list(deoxgen_rate  = "all",species_richness_ln = unname(warming_q)))
p1 <- as.data.frame(p1)

historical_temp <- c("Low"= "#619CFF",  "Medium" = "#4DAF4A",   "High"= "#F8766D"  )
p1$historical_temp[p1$group=="1.098612289"]<-"Low";p1$historical_temp[p1$group=="2.397895273"]<-"Medium";p1$historical_temp[p1$group=="3.713572067"]<-"High"
Fig4_ps<-ggplot(p1, aes(x = x, y = predicted, color = historical_temp, fill = historical_temp)) +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high), alpha = 0.18, color = NA) +
  geom_line(linewidth = 1)+
  theme_bw() +
  #theme_minimal()+
  scale_color_manual(values = historical_temp, breaks = c("Low","Medium","High")) +
  scale_fill_manual(values = historical_temp,  breaks = c("Low","Medium","High")) +
  labs(
    title = "Deoxygenation � Species richness",
    x=expression(paste(bold(symbol('\254'))," Deoxygenation [mg per litre/year]")),
    #y=expression(atop("Ln(species stability)",paste(" higher stability",bold(symbol('\256'))))),
    y="Ln(species stability)",
    #y="Ln(Species stability [whole fish])",
    color = "species richness",
    fill  = "species richness" )+
  theme(legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 11),
        
        axis.title.x = element_text(face = "bold", size = 11),
        axis.text.x = element_text(face = "bold", size = 10),
        axis.title.y = element_text(size = 12),
        axis.text.y = element_text(face = "bold", size = 10),
        legend.title = element_blank(),
        legend.text = element_text(size = 10))+
  guides(color = guide_legend(nrow = 2,byrow = TRUE),fill = guide_legend(nrow = 2,byrow = TRUE)) +scale_y_continuous(limits = c(-3, 2.2))



Fig4_ps




# ##################################
library(cowplot)
X11(width=18, height=18)

prow <-plot_grid(
  
  Fig3_ps + theme(legend.position="bottom"),
  Fig2_ps + theme(legend.position="bottom"),
  Fig4_ps+ theme(legend.position="bottom"),
  Fig1_ps + theme(legend.position="bottom"),
  #Fig4 + theme(legend.position="none"),
  align = 'vh',
  labels = c("a","b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l"),
  label_size = 12,
  hjust = -0,
  ncol  = 4,
  nrow  = 1)


plot_grid(prow) #0.1 is lengend 0.1 height

ggsave(filename = "Fig 3.png", width = 300, height = 120, dpi = 600, units = "mm", device='png')




########################## Figure 4

summary(model_full_4<-glmmTMB(CV_community_ln ~ scale(Average_species_stability_weighted_ln)+(1 | type), 
                              data = dataset_fishstability, family = gaussian())) # deoxgen_rate PH_rate


#####  Average_species_stability_weighted_ln
p1 <- ggpredict(model_full_4, c("Average_species_stability_weighted_ln [all]"))
p1 <- as.data.frame(p1)

Fig2<-ggplot(p1, aes(x = x, y = predicted)) +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high), alpha = 0.18, color = NA) +
  geom_point(data = dataset_fishstability,aes(x = Average_species_stability_weighted_ln, y = CV_community_ln),color = "#619CFF",alpha = 0.55,size = 1) +
  geom_line(linewidth = 1)+
  theme_bw() +
  #theme_minimal()+
  labs(
    title = "",
    #y=expression(atop("Ln(Community stability [whole fish])",paste(" higher stability",bold(symbol('\256'))))),
    #x="Ln(Species stability [whole fish])",
    y=expression(atop("Ln(fish community stability)",paste(" higher stability",bold(symbol('\256'))))),
    x="Ln(species stability)",
    
    color = "species richness",
    fill  = "species richness" )+
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 10),
        
        axis.title.x = element_text(size = 10),
        axis.text.x = element_text( size = 10), #element_text(face = "bold", size = 12),
        axis.title.y = element_text(size = 10),
        axis.text.y = element_text( size = 10),
        legend.title = element_text(size = 10),
        legend.text = element_text(size = 10))



Fig2


